# Typescript

Adds typescript to your current project. 
Contains:
- tsconfig.json
- lupi.ts Bundle
- ts folder structure

> This is part of the [Template Extractor Archives Repository](https://gitlab.lupcom.de/jbath/template-extractor-archives)