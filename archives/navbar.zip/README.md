# Contao Navbar

Adds the following to your current contao installation:
- mod_navigation.html5 template
- nav_default.html5 template
- SCSS and JS for the navbar

> This is part of the [Template Extractor Archives Repository](https://gitlab.lupcom.de/jbath/template-extractor-archives)