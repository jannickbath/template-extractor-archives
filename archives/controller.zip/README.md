# Contao Controller

Adds the following to your current contao installation:
- Controller for content element
- Template for that content element
- Creates an entry in the services.yml, if it doesn't exist already to make sure that the content elements are loaded

> This is part of the [Template Extractor Archives Repository](https://gitlab.lupcom.de/jbath/template-extractor-archives)