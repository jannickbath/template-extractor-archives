<?php

$strName = "{parent_table_name}";

// Fields

$GLOBALS['TL_LANG'][$strName]["name"] = [
    "Name"
];


// Legends
$GLOBALS['TL_LANG'][$strName]['description_legend'] = 'Beschreibung';
