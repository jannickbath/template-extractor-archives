# Contao Backend Module

Adds the following to your current contao installation:
- A parent dca table (group)
- A child dca table
- Models for each table
- Languages for each table
- An entry in config.php, for registering the backend module

Includes sorting.

> This is part of the [Template Extractor Archives Repository](https://gitlab.lupcom.de/jbath/template-extractor-archives)