# Contao Onepager Navigation

Adds the following to your current contao installation:
- New module controller
- New entry in tl_modules
- Template for the module

> This is part of the [Template Extractor Archives Repository](https://gitlab.lupcom.de/jbath/template-extractor-archives)