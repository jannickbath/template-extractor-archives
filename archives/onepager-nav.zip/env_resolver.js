const { listDirectories, exists } = require('./helper.js');

function getBundles() {
    const lupDir = "src/Lupcom";
    let bundles = []

    if (exists(lupDir)) {
        console.log(listDirectories("./"));
        bundles = listDirectories(lupDir);
    }

    return arrToStdoutList(bundles);
}

function arrToStdoutList(arr) {
    return arr.map(item => item + "\n").join("");
}

exports.getBundles = getBundles;