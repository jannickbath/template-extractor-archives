# Contao dca entry

Adds the following to your current contao installation:
- Table in `dca/`
- Language definitions in `languages/de`, if there are none yet

> This is part of the [Template Extractor Archives Repository](https://gitlab.lupcom.de/jbath/template-extractor-archives)